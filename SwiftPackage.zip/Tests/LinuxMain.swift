import XCTest

import CMPushTests

var tests = [XCTestCaseEntry]()
tests += CMPushTests.allTests()
XCTMain(tests)
