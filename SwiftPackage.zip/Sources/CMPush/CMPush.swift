struct CMPush {
    var text = "Hello, World!"
}
